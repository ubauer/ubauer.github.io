#ifndef EXAMPLE_H_
#define EXAMPLE_H_

void test();
class Example
{
public:
	static void test();
};
#endif /*EXAMPLE_H_*/
