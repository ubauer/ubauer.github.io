/*				FlashROF.h  by Tom Goldstein
 *   This code performs isotropic ROF denoising using the "Split Bregman" algorithm.
 * An image of dimensions mxn is denoised using the following command
 * 
 *   rof_iso(u,f,x,y,bx,by,mu,lambda,nGS,nBreg,m,n);
 * 
 * where:
 * 
 *   - u is an mxn array which holds the denoised image
 *   - f is the mxn noisy image
 *   - x is the (m-1)xn array which holds the x-derivative (I call this d_x in the paper)
 *   - y is the mx(n-1) array which holds the y-derivative
 *   - bx is the (m-1)xn array which holds the Bregman parameter associated with x
 *   - by is the mx(n-1) array which holds the Bregman parameter associated with y 
 *   - mu is the weighting parameter for the fidelity term (mu should be about 0.5 for images with pixels on the 0-255 scale)
 *   - lambda is the Bregman weight (usually, one should choose lambda=mu)
 *   - nGS is the number of Gauss-Seidel sweeps per iteration (I recommend choosing nGS=1) 
 *   - nBreg is the total number of iterations of Split-Bregman to be performed (50 works well for most applications)
 *  
 */

#ifndef FLASHROF_H_
#define FLASHROF_H_

typedef float num;

#include <cmath>

#include <iostream>




/******************Isotropic TV**************/
template <typename Matrix>
void rof_iso(Matrix& u, Matrix& f, Matrix& x, Matrix& y, Matrix& bx, Matrix& by ,
					   double mu, double lambda, int nGS, int nBreg, int width, int height){
	for(int breg=0;breg<nBreg;breg++){
		gs_iso(u,f,x,y,bx,by,mu,lambda,width, height,nGS);
		bregmanX(x,u,bx,width,height);
		bregmanY(y,u,by,width,height);
		std::cout << ".";
	}
}	


template <typename Matrix>
void gs_iso(Matrix& u, Matrix& f, Matrix& x, Matrix& y, Matrix& bx, Matrix& by , double mu, double lambda, int width, int height, int iter){
	for(int j=0;j<iter;j++){
		gsU(u,f,x,y,bx,by,mu,lambda,width,height);
		gsSpace(u,x,y,bx,by,lambda,width,height);
		
	}
}


/******************Anisotropic TV**************/
template <typename Matrix>
void rof_an(Matrix& u, Matrix& f, Matrix& x, Matrix& y, Matrix& bx, Matrix& by ,
					  double mu, double lambda, int nGS, int nBreg, int width, int height){
	for(int breg=0;breg<nBreg;breg++){
		gs_an(u,f,x,y,bx,by,mu,lambda,width, height,nGS);
		bregmanX(x,u,bx,width,height);
		bregmanY(y,u,by,width,height);
		std::cout << ".";
		std::cout.flush();
	}
}	


template <typename Matrix>
void gs_an(Matrix& u, Matrix& f, Matrix& x, Matrix& y, Matrix& bx, Matrix& by , double mu, double lambda, int width, int height, int iter){
	for(int j=0;j<iter;j++){
		gsU(u,f,x,y,bx,by,mu,lambda,width,height);
		gsX(u,x,bx,lambda,width,height);
		gsY(u,y,by,lambda,width,height);
	}
}





/****Relaxation operators****/

template <typename Matrix>
void gsU(Matrix& u, Matrix& f, Matrix& x, Matrix& y, Matrix& bx, Matrix& by , double mu, double lambda, int width, int height){
	int w,h;
	double sum;
	for(w=0;w<width;w++){		// do the central pixels
		for(h=0;h<height;h++){
			sum = 0.;
			sum += (w==0) ? 0 : (x[w-1][h] - bx[w-1][h] + u[w-1][h]);
			sum += (w==width-1) ? 0 : (-x[w][h] + bx[w][h] + u[w+1][h]);
			sum += (h==0) ? 0 : (y[w][h-1] - by[w][h-1] + u[w][h-1]);
			sum += (h==height-1) ? 0 : (-y[w][h] + by[w][h] + u[w][h+1]);
			sum*=lambda;
			sum+=mu*f[w][h];
			int numNeighbors = (w==0 || w==width-1 ? 1 : 2) + (h==0 || h==height-1 ? 1 : 2);
			sum/=mu+numNeighbors*lambda;
			u[w][h] = sum;
		}
	}
}


template <typename Matrix>
void gsSpace(Matrix& u, Matrix& x, Matrix& y, Matrix& bx, Matrix& by, double lambda, int width, int height){
	int w,h;
	num a,b,s;
	num flux = 1.0/lambda;
	num mflux = -1.0/lambda;
	num flux2 = flux*flux;
	for(w=0;w<width-1;w++){	
		for(h=0;h<height-1;h++){
			a =  u[w+1][h]-u[w][h]+bx[w][h];
			b =  u[w][h+1]-u[w][h]+by[w][h];
			s = a*a+b*b;
			if(s<flux2){x[w][h]=0;y[w][h]=0;continue;}
			s = sqrt(s);
			s=(s-flux)/s;
			x[w][h] = s*a;
			y[w][h] = s*b;
		}
	}		
	num base;
	h = height-1;
	for(w=0;w<width-1;w++){	
		base =  u[w+1][h]-u[w][h]+bx[w][h];
		if(base>flux) {x[w][h] = base-flux; continue;}
		if(base<mflux){x[w][h] = base+flux; continue;}
		x[w][h] = 0;
	}
	w = width-1;
	for(h=0;h<height-1;h++){	
		base =  u[w][h+1]-u[w][h]+by[w][h];
		if(base>flux) {y[w][h] = base-flux; continue;}
		if(base<mflux){y[w][h] = base+flux; continue;}
		y[w][h] = 0;
	}
}


template <typename Matrix>
void gsX(Matrix& u, Matrix& x, Matrix& bx , double lambda, int width, int height){
	width = width-1;
	int w,h;
	double base;				
	const double flux = 1.0/lambda;
	const double mflux = -1.0/lambda;
	for(w=0;w<width;w++){
		for(h=0;h<height;h++){
			base = u[w+1][h]-u[w][h]+bx[w][h];
			if(base>flux) {x[w][h] = base-flux; continue;}
			if(base<mflux){x[w][h] = base+flux; continue;}
			x[w][h] = 0;
		}
	}
}

template <typename Matrix>
void gsY(Matrix& u, Matrix& y, Matrix& by , double lambda, int width, int height){
	height = height-1;
	int w,h;
	double base;				
	const double flux = 1.0/lambda;
	const double mflux = -1.0/lambda;
	for(w=0;w<width;w++){
		for(h=0;h<height;h++){
			base = u[w][h+1]-u[w][h]+by[w][h];
			if(base>flux) {y[w][h] = base-flux; continue;}
			if(base<mflux){y[w][h] = base+flux; continue;}
			y[w][h] = 0;
		}
	}
}

template <typename Matrix>
void bregmanX(Matrix& x,Matrix& u, Matrix& bx, int width, int height){
	int w,h;
	double d;
	for(w=0;w<width-1;w++){
		for(h=0;h<height;h++){
			d = u[w+1][h]-u[w][h];
			bx[w][h]+= d-x[w][h];		
		}
	}
}


template <typename Matrix>
void bregmanY(Matrix& y,Matrix& u, Matrix& by, int width, int height){
	int w,h;
	double d;
	int hSent = height-1;
	for(w=0;w<width;w++){
		for(h=0;h<hSent;h++){
			d = u[w][h+1]-u[w][h];
			by[w][h]+= d-y[w][h];
		}
	}
}

/************************memory****************/

num** newMatrix(int rows, int cols){
	num* a = new num[rows*cols];
	num** rval = new num*[rows];
	if(rval==0 || a == 0){
		std::cout<<"ERROR: Out of Memory\n";
		std::exit(0);
	}
	int j;
	rval[0] = a;
	for(j=1;j<rows;j++)
		rval[j] = &a[j*cols];
	int g;
	for(j=0;j<rows;j++)
		for(g=0;g<cols;g++)
			rval[j][g] = 0;
	return rval;
	//		num** rval = new num*[rows];
	//		for(int j=0;j<rows;j++)
	//			rval[j] = new num[cols];
	//		return rval;
}
void deleteMatrix(num ** a){
	delete[] a[0];
	delete[] a;
}

#endif /*FLASHROF_H_*/
