#include <iostream>
#include <time.h>
#include "FlashROF.h"
#include "Example.h"
using namespace std;



void Example::test(){  
	
	int n=256;		// the width and height of the image
	double mu = .1;
	double lambda=.2;
	int nGS = 1;			// number of Gauss-Seidel iterations per loop
	int nIter = 30;			// total iterations to perform per denoise
	
	num** f = FlashROF::newMatrix(n,n);
	num** u = FlashROF::newMatrix(n,n);
	num** x = FlashROF::newMatrix(n-1,n);
	num** y = FlashROF::newMatrix(n,n-1);
	num** bx = FlashROF::newMatrix(n-1,n);
	num** by = FlashROF::newMatrix(n,n-1);
	
	int r,c;			//  load the "test image" into f
	for(r=0;r<n;r++)
		for(c=0;c<n;c++){
			f[r][c] = 1+r+c;
		}
	
				//  To denoise the image with Isotropic Split bregman,
				//     just do this:
	FlashROF::rof_iso(u,f,x,y,bx,by,mu,lambda,nGS,nIter,n,n);


				// Now, let's do some time trials
	
	int nCycles = 50;		// we'll denoise the image this many times
	
	clock_t start = clock();  //record the start time
		
	int j;
	for(j=0;j<nCycles;j++){		// GO!
		
		FlashROF::rof_iso(u,f,x,y,bx,by,mu,lambda,nGS,nIter,n,n);	
//		FlashROF::gsU(u,f,x,y,bx,by,mu,lambda,n,n);
//		FlashROF::gsSpace(u,x,y,bx,by,lambda,n,n);
//		FlashROF::bregmanX(x,u,bx,n,n);
//		FlashROF::bregmanY(y,u,by,n,n);
			
	}		// STOP!
	
	clock_t stop = clock();  // record the end time
						// report the results
	cout<<"Time elapsed = "<<(stop-start)/1000000.0<<"\n";
	cout<<"Time elapsed/denoise = "<<(stop-start)/nCycles/1000000.0<<"\n";
	
	
	return;
}
